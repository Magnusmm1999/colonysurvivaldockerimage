#!/bin/bash

docker build -t didstopia/colony-survival-server:latest .
