#!/bin/bash

docker build --no-cache -t didstopia/colony-survival-server:latest .
