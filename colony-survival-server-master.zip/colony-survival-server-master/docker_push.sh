#!/bin/bash

docker tag didstopia/colony-survival-server:latest didstopia/colony-survival-server:latest
docker push didstopia/colony-survival-server:latest